#!/bin/bash

# StickLLM Setup Script
# Automates downloading models and llama.cpp binaries

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

echo -e "${BLUE}╔════════════════════════════════════╗${NC}"
echo -e "${BLUE}║    StickLLM Setup Assistant       ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════╝${NC}"
echo

# Detect OS
OS=$(uname -s)
ARCH=$(uname -m)

echo -e "${YELLOW}Detected OS: ${NC}$OS $ARCH"
echo

# Check for required tools
check_tool() {
    if ! command -v $1 &> /dev/null; then
        echo -e "${RED}Error: $1 is not installed${NC}"
        echo -e "${YELLOW}Please install $1 first${NC}"
        exit 1
    fi
}

echo -e "${BLUE}Checking requirements...${NC}"
check_tool curl
check_tool python3

# Check for pip
if ! python3 -m pip --version &> /dev/null; then
    echo -e "${YELLOW}Installing pip...${NC}"
    curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py
    python3 get-pip.py --user
    rm get-pip.py
fi

# Install Python dependencies
echo -e "${BLUE}Installing Python dependencies...${NC}"
python3 -m pip install --user requests pyyaml huggingface-hub

echo

# Menu for model selection
echo -e "${GREEN}═══════════════════════════════════${NC}"
echo -e "${GREEN}   Step 1: Select Model to Download${NC}"
echo -e "${GREEN}═══════════════════════════════════${NC}"
echo
echo "Choose a model to download:"
echo
echo "  ${CYAN}1)${NC} DeepSeek Coder 6.7B Q5_K_M (~5GB) - Fast, good for testing"
echo "  ${CYAN}2)${NC} DeepSeek Coder 33B Q4_K_M (~20GB) - Powerful, best for architecture"
echo "  ${CYAN}3)${NC} Qwen2.5 Coder 32B Q5_K_M (~22GB) - Excellent reasoning"
echo "  ${CYAN}4)${NC} Download both 6.7B and 33B (recommended for 1TB drive)"
echo "  ${CYAN}5)${NC} Skip model download (I'll do it manually)"
echo

read -p "Enter choice [1-5]: " model_choice

download_model() {
    local repo=$1
    local file=$2
    local name=$3
    
    echo -e "${BLUE}Downloading $name...${NC}"
    echo "This may take a while depending on your internet speed."
    echo
    
    python3 -c "
from huggingface_hub import hf_hub_download
import os

try:
    print('Downloading from HuggingFace...')
    file_path = hf_hub_download(
        repo_id='$repo',
        filename='$file',
        local_dir='$SCRIPT_DIR/models',
        local_dir_use_symlinks=False
    )
    print(f'Downloaded to: {file_path}')
except Exception as e:
    print(f'Error: {e}')
    exit(1)
"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ Successfully downloaded $name${NC}"
        echo
    else
        echo -e "${RED}✗ Failed to download $name${NC}"
        echo -e "${YELLOW}You can download manually from https://huggingface.co/$repo${NC}"
        echo
    fi
}

case $model_choice in
    1)
        download_model "TheBloke/deepseek-coder-6.7B-instruct-GGUF" \
                      "deepseek-coder-6.7b-instruct.Q5_K_M.gguf" \
                      "DeepSeek Coder 6.7B"
        ;;
    2)
        download_model "TheBloke/deepseek-coder-33B-instruct-GGUF" \
                      "deepseek-coder-33b-instruct.Q4_K_M.gguf" \
                      "DeepSeek Coder 33B"
        ;;
    3)
        download_model "Qwen/Qwen2.5-Coder-32B-Instruct-GGUF" \
                      "qwen2.5-coder-32b-instruct-q5_k_m.gguf" \
                      "Qwen2.5 Coder 32B"
        ;;
    4)
        download_model "TheBloke/deepseek-coder-6.7B-instruct-GGUF" \
                      "deepseek-coder-6.7b-instruct.Q5_K_M.gguf" \
                      "DeepSeek Coder 6.7B"
        download_model "TheBloke/deepseek-coder-33B-instruct-GGUF" \
                      "deepseek-coder-33b-instruct.Q4_K_M.gguf" \
                      "DeepSeek Coder 33B"
        ;;
    5)
        echo -e "${YELLOW}Skipping model download${NC}"
        echo -e "${YELLOW}Remember to download a model manually to models/${NC}"
        echo
        ;;
    *)
        echo -e "${RED}Invalid choice${NC}"
        exit 1
        ;;
esac

# Download llama.cpp binary
echo
echo -e "${GREEN}═══════════════════════════════════${NC}"
echo -e "${GREEN}   Step 2: Download llama.cpp${NC}"
echo -e "${GREEN}═══════════════════════════════════${NC}"
echo

get_latest_release() {
    curl -s https://api.github.com/repos/ggerganov/llama.cpp/releases/latest | \
        python3 -c "import sys, json; print(json.load(sys.stdin)['tag_name'])"
}

download_llamacpp() {
    local platform=$1
    local arch=$2
    local dest=$3
    
    echo -e "${BLUE}Downloading llama.cpp for $platform...${NC}"
    
    LATEST_TAG=$(get_latest_release)
    echo "Latest version: $LATEST_TAG"
    
    DOWNLOAD_URL="https://github.com/ggerganov/llama.cpp/releases/download/${LATEST_TAG}/llama-${LATEST_TAG}-${platform}.zip"
    
    echo "Downloading from: $DOWNLOAD_URL"
    
    mkdir -p "/tmp/stickllm-setup"
    cd "/tmp/stickllm-setup"
    
    if curl -L -o "llama.zip" "$DOWNLOAD_URL"; then
        echo "Extracting..."
        unzip -q "llama.zip"
        
        # Find the server binary
        if [ "$platform" = "win-*" ]; then
            BINARY_NAME="llama-server.exe"
        else
            BINARY_NAME="llama-server"
        fi
        
        BINARY=$(find . -name "$BINARY_NAME" -type f | head -n 1)
        
        if [ -n "$BINARY" ]; then
            mkdir -p "$dest"
            cp "$BINARY" "$dest/"
            chmod +x "$dest/$BINARY_NAME"
            echo -e "${GREEN}✓ Installed to $dest/$BINARY_NAME${NC}"
        else
            echo -e "${RED}✗ Could not find $BINARY_NAME in download${NC}"
            return 1
        fi
        
        cd "$SCRIPT_DIR"
        rm -rf "/tmp/stickllm-setup"
        return 0
    else
        echo -e "${RED}✗ Download failed${NC}"
        return 1
    fi
}

case "$OS" in
    Linux*)
        echo "Downloading for Linux x64..."
        download_llamacpp "linux-x64" "x64" "$SCRIPT_DIR/runtime/linux"
        ;;
    Darwin*)
        if [ "$ARCH" = "arm64" ]; then
            echo "Downloading for macOS ARM64 (M1/M2)..."
            download_llamacpp "macos-arm64" "arm64" "$SCRIPT_DIR/runtime/macos"
        else
            echo "Downloading for macOS x64 (Intel)..."
            download_llamacpp "macos-x64" "x64" "$SCRIPT_DIR/runtime/macos"
        fi
        ;;
    *)
        echo -e "${YELLOW}Automatic download not supported for $OS${NC}"
        echo -e "${YELLOW}Please download manually from:${NC}"
        echo "https://github.com/ggerganov/llama.cpp/releases"
        ;;
esac

echo

# Summary
echo -e "${GREEN}═══════════════════════════════════${NC}"
echo -e "${GREEN}        Setup Complete!            ${NC}"
echo -e "${GREEN}═══════════════════════════════════${NC}"
echo

echo -e "${BLUE}What's next:${NC}"
echo
echo "1. Check that you have a model in models/"
ls -lh models/*.gguf 2>/dev/null && echo -e "${GREEN}   ✓ Model found${NC}" || echo -e "${YELLOW}   ! No model found - download one${NC}"
echo

echo "2. Check that you have llama.cpp binary"
case "$OS" in
    Linux*)
        [ -f "runtime/linux/llama-server" ] && echo -e "${GREEN}   ✓ Linux binary found${NC}" || echo -e "${YELLOW}   ! Linux binary missing${NC}"
        ;;
    Darwin*)
        [ -f "runtime/macos/llama-server" ] && echo -e "${GREEN}   ✓ macOS binary found${NC}" || echo -e "${YELLOW}   ! macOS binary missing${NC}"
        ;;
esac
echo

echo "3. Ready to launch!"
echo -e "   Run: ${CYAN}./launch.sh${NC}"
echo

echo -e "${BLUE}Optional: Add Moontalk documentation${NC}"
echo "   Add your project docs to: context/moontalk/"
echo "   Example architecture.md is already there"
echo

echo -e "${GREEN}Happy coding! 🚀${NC}"
