# StickLLM Architecture

## System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         YOUR USB DRIVE                          │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │                      StickLLM System                      │ │
│  │                                                           │ │
│  │  ┌─────────────┐  ┌──────────────┐  ┌────────────────┐ │ │
│  │  │   Models    │  │   Runtime    │  │      CLI       │ │ │
│  │  │             │  │              │  │                │ │ │
│  │  │ 6.7B Model  │  │  llama.cpp   │  │  stickllm.py   │ │ │
│  │  │ 33B Model   │  │   server     │  │   Terminal     │ │ │
│  │  │   (GGUF)    │  │              │  │   Interface    │ │ │
│  │  └─────────────┘  └──────────────┘  └────────────────┘ │ │
│  │                                                           │ │
│  │  ┌─────────────┐  ┌──────────────┐  ┌────────────────┐ │ │
│  │  │  Context    │  │    Chats     │  │    Config      │ │ │
│  │  │             │  │              │  │                │ │ │
│  │  │ Moontalk    │  │ sessions.db  │  │  config.yaml   │ │ │
│  │  │  Docs       │  │   SQLite     │  │   Personas     │ │ │
│  │  │             │  │              │  │                │ │ │
│  │  └─────────────┘  └──────────────┘  └────────────────┘ │ │
│  └───────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
                              │
                              │ USB 3.1+
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      ANY COMPUTER                               │
│                                                                 │
│  Work Laptop  │  Home Desktop  │  Travel Laptop  │  etc...     │
└─────────────────────────────────────────────────────────────────┘
```

## Data Flow

```
┌─────────────────────────────────────────────────────────────────────┐
│ STEP 1: USER PLUGS IN USB & LAUNCHES                               │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  launch.sh detects OS & starts server  │
        └─────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│ STEP 2: llama.cpp SERVER LOADS MODEL INTO RAM                      │
└─────────────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┴─────────────────────┐
        │                                           │
        ▼                                           ▼
┌──────────────┐                           ┌──────────────┐
│  6.7B Model  │    or                     │  33B Model   │
│  (~5GB RAM)  │                           │  (~24GB RAM) │
│   Fast       │                           │   Powerful   │
└──────────────┘                           └──────────────┘
        │                                           │
        └─────────────────────┬─────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │   Server running at localhost:8080     │
        └─────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│ STEP 3: CLI LAUNCHES INTERACTIVE TERMINAL                           │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  User types message in terminal        │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  CLI loads context files (optional)    │
        │  - architecture.md                     │
        │  - tech-stack.md                       │
        │  - your-code.py                        │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  CLI builds prompt with:               │
        │  - System instructions (persona)       │
        │  - Context files                       │
        │  - Conversation history                │
        │  - User's current message              │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  Sends to localhost:8080/completion    │
        └─────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│ STEP 4: MODEL GENERATES RESPONSE                                    │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  Response streams back token-by-token  │
        │  Printed in real-time to terminal      │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  Both messages saved to sessions.db    │
        │  (on USB drive)                        │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  Ready for next user message           │
        │  Full context maintained               │
        └─────────────────────────────────────────┘
```

## Multi-Device Workflow

```
MONDAY - Office Computer
┌────────────────────────────┐
│ Start session discussing   │
│ CommandOS architecture     │
│ ID: Session 42             │
└────────────────────────────┘
         │
         │ Saved to USB
         ▼
    [USB Drive]
         │
         │ Plug into home computer
         ▼
MONDAY EVENING - Home Computer
┌────────────────────────────┐
│ Resume Session 42          │
│ Continue discussion        │
│ Add more thoughts          │
└────────────────────────────┘
         │
         │ Saved to USB
         ▼
    [USB Drive]
         │
         │ Plug into laptop
         ▼
TUESDAY - Travel Laptop
┌────────────────────────────┐
│ Resume Session 42          │
│ Implement discussed ideas  │
│ Full context available     │
└────────────────────────────┘
```

## Privacy Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    YOUR USB DRIVE                           │
│                                                             │
│  All data stays here:                                      │
│  • AI Models (never leave)                                 │
│  • Conversations (never uploaded)                          │
│  • Context files (private)                                 │
│  • Configuration (local)                                   │
└─────────────────────────────────────────────────────────────┘
                           │
                           │ All processing local
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                    YOUR COMPUTER                            │
│                                                             │
│  • Model runs in RAM                                       │
│  • No internet connection needed                           │
│  • No telemetry                                            │
│  • No cloud API calls                                      │
└─────────────────────────────────────────────────────────────┘

         🚫 NEVER GOES TO ☁️  CLOUD
```

## Component Interaction

```
                    ┌──────────────┐
                    │     USER     │
                    └──────┬───────┘
                           │
                           │ Types commands
                           ▼
                    ┌──────────────┐
            ┌───────│  stickllm.py │───────┐
            │       │     (CLI)    │       │
            │       └──────────────┘       │
            │                              │
            │                              │
    Reads   │                              │ HTTP API
   Context  │                              │ Requests
            │                              │
            ▼                              ▼
    ┌──────────────┐            ┌──────────────────┐
    │   Context    │            │  llama.cpp       │
    │    Files     │            │  Server          │
    │              │            │  (localhost:8080)│
    │ - .md files  │            └────────┬─────────┘
    │ - .py files  │                     │
    │ - .yaml etc  │                     │ Loads
    └──────────────┘                     │
                                         ▼
                                ┌──────────────────┐
                                │   AI Model       │
                                │   (GGUF)         │
                                │                  │
                                │ - 6.7B or        │
                                │ - 33B            │
                                └──────────────────┘
            │                              │
            │                              │
    Saves   │                              │ Returns
  Messages  │                              │ Response
            │                              │
            ▼                              ▼
    ┌──────────────┐            ┌──────────────────┐
    │  sessions.db │◄───────────│   stickllm.py    │
    │   (SQLite)   │   Stores   │                  │
    │              │            └──────────────────┘
    └──────────────┘                     │
                                         │ Displays
                                         ▼
                                  ┌──────────────┐
                                  │   Terminal   │
                                  │   Output     │
                                  └──────────────┘
```

## Model Size vs Performance Trade-off

```
MODEL SIZE               SPEED              QUALITY
                    
6.7B  ████            ████████████        ████████
      Small           Very Fast          Good
      ~5GB RAM        30-50 tok/s        Quick Q&A
                                         
13B   ████████        ████████            ██████████
      Medium          Fast                Better
      ~10GB RAM       20-30 tok/s        General use
                                         
33B   ████████████    ████                ████████████
      Large           Slower              Excellent
      ~24GB RAM       10-20 tok/s        Architecture
                                         
                    ↑ More cores         ↑ Reasoning
                    ↑ Better CPU         ↑ Context
                                         ↑ Accuracy
```

## Session Persistence

```
SESSION LIFECYCLE

1. Create Session
   ┌─────────────────┐
   │ New conversation│
   │ ID assigned     │
   │ Timestamp       │
   └────────┬────────┘
            │
            ▼
2. Add Messages
   ┌─────────────────┐
   │ User: question  │
   │ AI: response    │
   │ User: followup  │
   │ AI: answer      │
   └────────┬────────┘
            │
            ▼
3. Save to Database
   ┌─────────────────┐
   │ sessions.db     │
   │ on USB drive    │
   └────────┬────────┘
            │
            │
4. Later: Resume Session
   ┌─────────────────┐
   │ Load messages   │
   │ Restore context │
   │ Continue chat   │
   └─────────────────┘

   ALL DATA TRAVELS WITH USB
```

This architecture ensures:
✅ Complete privacy (all local)
✅ Full portability (works anywhere)
✅ Persistent memory (across devices)
✅ No dependencies (self-contained)
✅ Fast performance (local inference)
