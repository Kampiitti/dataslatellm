# StickLLM Quick Reference

## First Time Setup
```bash
cd /path/to/usb/stickllm
./setup.sh              # Downloads model and llama.cpp
```

## Daily Use

### Start Interactive Chat
```bash
./launch.sh             # Start new conversation
./launch.sh --session 5 # Resume session 5
```

### Quick Questions
```bash
./launch.sh ask "your question here"
```

### List Past Sessions
```bash
./launch.sh sessions
```

## In-Chat Commands

| Command | Description |
|---------|-------------|
| `/help` | Show help |
| `/exit` | Exit chat |
| `/new` | Start new session |
| `/context` | Show loaded files |
| `/context add file.py` | Add file to context |
| `/context clear` | Clear context |

## Common Workflows

### Architecture Discussion
```bash
./launch.sh
/context add context/moontalk/architecture.md
```

### Code Review
```bash
./launch.sh
/context add path/to/code.py
```

### Debug Help
```bash
/context add error.log
/context add src/problem_file.py
```

## File Locations

```
stickllm/
├── models/              # Your GGUF models
├── context/moontalk/    # Project documentation
├── chats/sessions.db    # All conversations
└── runtime/             # llama.cpp binaries
```

## Tips

- Load context files before asking questions
- Use `--session` to continue discussions
- Bigger models (33B) for architecture, smaller (6.7B) for quick help
- Keep project docs in `context/` folder

## Troubleshooting

### Server won't start
```bash
cat server.log          # Check errors
lsof -i :8080          # Check if port in use
```

### Out of memory
- Use smaller model (6.7B instead of 33B)
- Close other applications
- Check available RAM: `free -h` (Linux) or Activity Monitor (Mac)

### Slow performance
- Ensure USB 3.0+ connection
- Use smaller model
- Reduce `--ctx-size` in launch.sh

## Model Quick Reference

| Model | Size | RAM | Speed | Best For |
|-------|------|-----|-------|----------|
| DeepSeek 6.7B Q5 | 5GB | 7GB | Fast | Quick questions |
| DeepSeek 33B Q4 | 20GB | 24GB | Medium | Architecture |
| Qwen2.5 32B Q5 | 22GB | 26GB | Medium | Complex reasoning |

## Getting Help

- Check README.md for full documentation
- Check SETUP_MOONTALK.md for detailed setup
- View logs: `cat server.log`
- Check server health: `curl http://localhost:8080/health`
