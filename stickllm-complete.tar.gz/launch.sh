#!/bin/bash

# StickLLM Launcher Script
# Detects OS, starts llama.cpp server, and launches CLI

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

echo -e "${BLUE}╔════════════════════════════════════╗${NC}"
echo -e "${BLUE}║        StickLLM Launcher          ║${NC}"
echo -e "${BLUE}║   Portable AI Coding Assistant    ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════╝${NC}"
echo

# Detect OS and architecture
OS=$(uname -s)
ARCH=$(uname -m)

echo -e "${YELLOW}Detected OS: ${NC}$OS"
echo -e "${YELLOW}Architecture: ${NC}$ARCH"
echo

# Set paths based on OS
case "$OS" in
    Linux*)
        RUNTIME_DIR="$SCRIPT_DIR/runtime/linux"
        LLAMA_BIN="$RUNTIME_DIR/llama-server"
        ;;
    Darwin*)
        RUNTIME_DIR="$SCRIPT_DIR/runtime/macos"
        LLAMA_BIN="$RUNTIME_DIR/llama-server"
        ;;
    MINGW*|MSYS*|CYGWIN*)
        echo -e "${RED}Windows detected. Please use launch.bat instead.${NC}"
        exit 1
        ;;
    *)
        echo -e "${RED}Unsupported OS: $OS${NC}"
        exit 1
        ;;
esac

# Check if llama.cpp binary exists
if [ ! -f "$LLAMA_BIN" ]; then
    echo -e "${RED}Error: llama.cpp server not found at: $LLAMA_BIN${NC}"
    echo -e "${YELLOW}Please download or compile llama.cpp for your platform.${NC}"
    echo -e "${YELLOW}See: https://github.com/ggerganov/llama.cpp${NC}"
    exit 1
fi

# Make sure binary is executable
chmod +x "$LLAMA_BIN"

# Model selection
MODEL_DIR="$SCRIPT_DIR/models"
DEFAULT_MODEL="$MODEL_DIR/deepseek-coder-6.7b-instruct.Q5_K_M.gguf"

# Find first available model
MODEL_FILE=""
if [ -f "$DEFAULT_MODEL" ]; then
    MODEL_FILE="$DEFAULT_MODEL"
else
    # Look for any .gguf file
    MODEL_FILE=$(find "$MODEL_DIR" -name "*.gguf" -type f | head -n 1)
fi

if [ -z "$MODEL_FILE" ]; then
    echo -e "${RED}Error: No model files found in $MODEL_DIR${NC}"
    echo -e "${YELLOW}Please download a GGUF model file.${NC}"
    echo -e "${YELLOW}Recommended: DeepSeek Coder 6.7B${NC}"
    echo -e "${YELLOW}Download from: https://huggingface.co/TheBloke/deepseek-coder-6.7B-instruct-GGUF${NC}"
    exit 1
fi

echo -e "${GREEN}Using model: ${NC}$(basename "$MODEL_FILE")"
echo

# Check if server is already running
if curl -s http://localhost:8080/health > /dev/null 2>&1; then
    echo -e "${YELLOW}Server is already running at http://localhost:8080${NC}"
else
    # Start llama.cpp server in background
    echo -e "${BLUE}Starting llama.cpp server...${NC}"
    
    # Determine number of threads (use half of available cores)
    if command -v nproc > /dev/null 2>&1; then
        N_THREADS=$(($(nproc) / 2))
    elif command -v sysctl > /dev/null 2>&1; then
        N_THREADS=$(($(sysctl -n hw.ncpu) / 2))
    else
        N_THREADS=4
    fi
    
    # Start server
    "$LLAMA_BIN" \
        -m "$MODEL_FILE" \
        --port 8080 \
        --ctx-size 8192 \
        --n-predict 2048 \
        --threads $N_THREADS \
        --log-disable \
        > "$SCRIPT_DIR/server.log" 2>&1 &
    
    SERVER_PID=$!
    echo $SERVER_PID > "$SCRIPT_DIR/server.pid"
    
    echo -e "${GREEN}Server started (PID: $SERVER_PID)${NC}"
    echo -e "${YELLOW}Waiting for server to initialize...${NC}"
    
    # Wait for server to be ready
    for i in {1..30}; do
        if curl -s http://localhost:8080/health > /dev/null 2>&1; then
            echo -e "${GREEN}Server is ready!${NC}"
            break
        fi
        sleep 1
        echo -n "."
    done
    echo
fi

# Check for Python
if ! command -v python3 > /dev/null 2>&1; then
    echo -e "${RED}Error: Python 3 is not installed${NC}"
    exit 1
fi

# Check for required Python packages
echo -e "${BLUE}Checking Python dependencies...${NC}"
python3 -c "import requests; import yaml" 2>/dev/null || {
    echo -e "${YELLOW}Installing required Python packages...${NC}"
    python3 -m pip install --user requests pyyaml
}

# Launch CLI
echo -e "${GREEN}Launching StickLLM CLI...${NC}"
echo

export PYTHONPATH="$SCRIPT_DIR/cli:$PYTHONPATH"
python3 "$SCRIPT_DIR/cli/stickllm.py" "$@"

# Cleanup function
cleanup() {
    if [ -f "$SCRIPT_DIR/server.pid" ]; then
        PID=$(cat "$SCRIPT_DIR/server.pid")
        if ps -p $PID > /dev/null 2>&1; then
            echo -e "\n${YELLOW}Stopping server (PID: $PID)...${NC}"
            kill $PID
            rm "$SCRIPT_DIR/server.pid"
        fi
    fi
}

# Register cleanup on exit
trap cleanup EXIT
